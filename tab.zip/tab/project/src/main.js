import Vue from 'vue'
import App from './App.vue'
Vue.use(window.vuelidate.default)
const { required, minLength } = window.validators

new Vue({
  el: '#app',
  render: h => h(App)
  

  
})
